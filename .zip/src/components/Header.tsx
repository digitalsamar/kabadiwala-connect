import React, { useState } from 'react';
import { UserRole, Language } from '../types';
import { getTranslation } from '../data/translations';
import { OfflineStore } from '../utils/offlineStore';
import { speechAssistant } from '../utils/speech';
import { 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  Volume2, 
  VolumeX, 
  ShieldCheck, 
  Truck, 
  Building2, 
  Landmark, 
  Coins
} from 'lucide-react';

interface HeaderProps {
  currentRole: UserRole;
  setRole: (role: UserRole) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  isOffline: boolean;
  setIsOffline: (offline: boolean) => void;
  pendingSyncCount: number;
  onSyncComplete: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  setRole,
  language,
  setLanguage,
  isOffline,
  setIsOffline,
  pendingSyncCount,
  onSyncComplete,
}) => {
  const t = getTranslation(language);
  const [isSyncing, setIsSyncing] = useState(false);
  const [audioMuted, setAudioMuted] = useState(false);

  const handleSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      OfflineStore.syncPendingLots();
      setIsSyncing(false);
      onSyncComplete();
      speechAssistant.speak(
        language === 'hi' ? 'सभी रसीदें सर्वर पर सिंक हो गईं।' :
        language === 'mr' ? 'सर्व नोंदी सिंक झाल्या आहेत.' :
        'All offline records synced successfully.',
        language
      );
    }, 900);
  };

  const toggleAudio = () => {
    if (audioMuted) {
      setAudioMuted(false);
      speechAssistant.speak(
        language === 'hi' ? 'आवाज़ चालू है' :
        language === 'mr' ? 'आवाज सुरू आहे' :
        'Audio assistance enabled',
        language
      );
    } else {
      speechAssistant.stop();
      setAudioMuted(true);
    }
  };

  const toggleOfflineMode = () => {
    const nextState = !isOffline;
    setIsOffline(nextState);
    OfflineStore.setForcedOffline(nextState);
    speechAssistant.speak(
      nextState 
        ? (language === 'hi' ? 'ऑफलाइन मोड चालू है।' : language === 'mr' ? 'ऑफलाइन मोड सुरू आहे.' : 'Offline mode active')
        : (language === 'hi' ? 'इंटरनेट ऑनलाइन है।' : language === 'mr' ? 'इंटरनेट ऑनलाइन आहे.' : 'Online mode restored'),
      language
    );
  };

  return (
    <header className="bg-stone-900 text-stone-100 border-b border-stone-800 sticky top-0 z-50 shadow-md">
      {/* Top Ministry / JNARDDC Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-stone-900 to-teal-950 px-4 py-1.5 text-xs flex flex-wrap items-center justify-between border-b border-emerald-800/40 text-emerald-200">
        <div className="flex items-center gap-2 font-medium">
          <span className="bg-emerald-500 text-stone-950 font-bold px-1.5 py-0.5 rounded text-[10px] tracking-wider uppercase">MoM • JNARDDC</span>
          <span className="hidden sm:inline">Ministry of Mines | E-Waste (Management) Rules 2022 Circular Chain</span>
          <span className="sm:hidden">Problem Statement #26229</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-[11px] text-stone-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            CPCB / SPCB Authorized Channel
          </span>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Brand & Tagline */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-stone-950 font-extrabold text-xl shadow-lg shadow-emerald-500/20">
              क
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-lg text-stone-50 tracking-tight flex items-center gap-1.5">
                  {t.appTitle}
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Pilot v1.0
                  </span>
                </h1>
              </div>
              <p className="text-xs text-stone-400 hidden sm:block">
                {t.appSubTitle}
              </p>
            </div>
          </div>

          {/* Mobile Right Controls */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={toggleAudio}
              className={`p-2 rounded-lg border text-xs font-semibold transition ${
                audioMuted 
                  ? 'bg-stone-800 text-stone-400 border-stone-700' 
                  : 'bg-emerald-950 text-emerald-300 border-emerald-600'
              }`}
              title="Voice Assistant"
            >
              {audioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>
            <button
              onClick={toggleOfflineMode}
              className={`px-2 py-1 rounded-lg border text-xs font-medium flex items-center gap-1 transition ${
                isOffline 
                  ? 'bg-amber-950 text-amber-300 border-amber-600' 
                  : 'bg-emerald-950 text-emerald-300 border-emerald-700'
              }`}
            >
              {isOffline ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
              <span>{isOffline ? 'Off' : 'On'}</span>
            </button>
          </div>
        </div>

        {/* Persona Selector Tabs */}
        <div className="flex items-center gap-1 bg-stone-950 p-1 rounded-xl border border-stone-800 overflow-x-auto no-scrollbar">
          <button
            id="role-collector-btn"
            onClick={() => setRole('collector')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentRole === 'collector'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-300 hover:text-white hover:bg-stone-800/60'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>{t.navCollector}</span>
          </button>

          <button
            id="role-recycler-btn"
            onClick={() => setRole('recycler')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentRole === 'recycler'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-300 hover:text-white hover:bg-stone-800/60'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>{t.navRecycler}</span>
          </button>

          <button
            id="role-admin-btn"
            onClick={() => setRole('admin')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentRole === 'admin'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-300 hover:text-white hover:bg-stone-800/60'
            }`}
          >
            <Landmark className="w-3.5 h-3.5" />
            <span>{t.navAdmin}</span>
          </button>

          <button
            id="role-economics-btn"
            onClick={() => setRole('economics')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentRole === 'economics'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-amber-300 hover:text-amber-200 hover:bg-amber-950/40'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>{t.navEconomics}</span>
          </button>
        </div>

        {/* Language & Connectivity Status Controls (Desktop) */}
        <div className="hidden md:flex items-center gap-3">
          {/* Vernacular Language Selector */}
          <div className="flex items-center bg-stone-950 rounded-lg p-0.5 border border-stone-800 text-xs font-semibold">
            <button
              onClick={() => setLanguage('hi')}
              className={`px-2.5 py-1 rounded transition ${
                language === 'hi'
                  ? 'bg-emerald-600 text-white'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              हिन्दी
            </button>
            <button
              onClick={() => setLanguage('mr')}
              className={`px-2.5 py-1 rounded transition ${
                language === 'mr'
                  ? 'bg-emerald-600 text-white'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              मराठी
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-2.5 py-1 rounded transition ${
                language === 'en'
                  ? 'bg-emerald-600 text-white'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              EN
            </button>
          </div>

          {/* Voice Assistant Toggle */}
          <button
            onClick={toggleAudio}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1.5 transition ${
              audioMuted 
                ? 'bg-stone-800 text-stone-400 border-stone-700' 
                : 'bg-emerald-950 text-emerald-300 border-emerald-600 shadow-sm'
            }`}
            title="Audio Readout (बोलकर सुनो)"
          >
            {audioMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />}
            <span>{audioMuted ? 'Muted' : 'Voice ON'}</span>
          </button>

          {/* Offline/Online Toggle Simulator */}
          <button
            onClick={toggleOfflineMode}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1.5 transition ${
              isOffline
                ? 'bg-amber-950/80 text-amber-300 border-amber-600'
                : 'bg-emerald-950/80 text-emerald-300 border-emerald-700'
            }`}
            title="Toggle Network Offline Simulator"
          >
            {isOffline ? <WifiOff className="w-3.5 h-3.5 text-amber-400" /> : <Wifi className="w-3.5 h-3.5 text-emerald-400" />}
            <span>{isOffline ? t.offline : t.online}</span>
          </button>

          {/* Sync Button if pending */}
          {pendingSyncCount > 0 && (
            <button
              onClick={handleSync}
              disabled={isSyncing}
              className="bg-amber-500 hover:bg-amber-400 text-stone-950 px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm transition animate-bounce"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{pendingSyncCount} {t.pendingSync}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
