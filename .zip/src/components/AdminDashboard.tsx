import React, { useState } from 'react';
import { MaterialCategoryInfo, Recycler, LotRecord, Language } from '../types';
import { getTranslation } from '../data/translations';
import { exportDatasetToCSV } from '../utils/csvExport';
import { 
  Landmark, 
  ShieldCheck, 
  TrendingUp, 
  Download, 
  Database, 
  AlertTriangle, 
  Sparkles, 
  Scale, 
  Coins, 
  FileSpreadsheet, 
  CheckCircle2, 
  BarChart3, 
  Users,
  Search,
  Filter
} from 'lucide-react';

interface AdminDashboardProps {
  categories: MaterialCategoryInfo[];
  recyclers: Recycler[];
  lots: LotRecord[];
  language: Language;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  categories,
  recyclers,
  lots,
  language,
}) => {
  const t = getTranslation(language);
  const [selectedDatasetTab, setSelectedDatasetTab] = useState<'materials' | 'prices' | 'recyclers' | 'transactions' | 'traceability'>('materials');
  const [anomalySearch, setAnomalySearch] = useState('');

  // Aggregated KPIs
  const totalWeightKg = lots.reduce((sum, l) => sum + (l.actualWeightKg || l.estimatedWeightKg), 0);
  const totalTonsDiverted = (totalWeightKg / 1000).toFixed(2);
  const totalValuePaid = lots.reduce((sum, l) => sum + (l.finalSaleValue || l.estimatedValue), 0);
  const totalCollectorUplift = lots.reduce((sum, l) => sum + l.priceUplift, 0);

  // Critical Mineral aggregates
  const totalCopperKg = Math.round(totalWeightKg * 0.18);
  const totalLithiumKg = (totalWeightKg * 0.015).toFixed(1);
  const totalCobaltKg = (totalWeightKg * 0.009).toFixed(1);
  const totalGoldGrams = (totalWeightKg * 0.045).toFixed(1);

  // Anomalies list (Lots > 200kg or flagged)
  const anomalyLots = lots.filter(
    (l) => (l.actualWeightKg || l.estimatedWeightKg) > 200 || l.priceUplift > 20000
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Ministry Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-stone-900 to-teal-950 text-white rounded-3xl p-6 shadow-xl border border-emerald-700/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-emerald-800/60 pb-5">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-stone-950 flex items-center justify-center font-black text-xl shadow-lg">
              <Landmark className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  PROBLEM STATEMENT #26229
                </span>
                <span className="text-xs text-stone-300">JNARDDC Oversight</span>
              </div>
              <h2 className="text-xl font-extrabold text-white mt-0.5">{t.adminTitle}</h2>
              <p className="text-xs text-stone-300">
                National E-Waste Circular Economy & Critical Minerals Traceability Platform
              </p>
            </div>
          </div>

          {/* Quick Export Master CSV */}
          <button
            onClick={() => exportDatasetToCSV('all', { categories, recyclers, lots })}
            className="bg-emerald-500 hover:bg-emerald-400 text-stone-950 px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-lg transition transform active:scale-95 self-start md:self-auto"
          >
            <Download className="w-4 h-4" />
            <span>{t.exportCsv}</span>
          </button>
        </div>

        {/* 4 Core National Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-5 text-xs">
          <div className="bg-stone-900/80 p-4 rounded-2xl border border-stone-800">
            <span className="text-stone-400 block mb-1">Total E-Waste Diverted</span>
            <div className="text-2xl sm:text-3xl font-extrabold font-display text-emerald-400">
              {totalTonsDiverted} <span className="text-sm font-normal text-stone-300">Tons</span>
            </div>
            <span className="text-[10px] text-emerald-300 font-medium block mt-1">
              🌱 Diverted from backyard fires
            </span>
          </div>

          <div className="bg-stone-900/80 p-4 rounded-2xl border border-stone-800">
            <span className="text-stone-400 block mb-1">Collector Income Uplift (₹)</span>
            <div className="text-2xl sm:text-3xl font-extrabold font-display text-emerald-300">
              ₹{totalCollectorUplift.toLocaleString('en-IN')}
            </div>
            <span className="text-[10px] text-emerald-300 font-medium block mt-1">
              📈 Direct informal worker wealth
            </span>
          </div>

          <div className="bg-stone-900/80 p-4 rounded-2xl border border-stone-800">
            <span className="text-stone-400 block mb-1">CPCB Licensed Recyclers</span>
            <div className="text-2xl sm:text-3xl font-extrabold font-display text-white">
              {recyclers.length} <span className="text-sm font-normal text-stone-400">Centers</span>
            </div>
            <span className="text-[10px] text-stone-300 font-medium block mt-1">
              ✅ 100% Chain-of-custody certified
            </span>
          </div>

          <div className="bg-stone-900/80 p-4 rounded-2xl border border-stone-800">
            <span className="text-stone-400 block mb-1">Total Verified Transactions</span>
            <div className="text-2xl sm:text-3xl font-extrabold font-display text-amber-400">
              {lots.length} <span className="text-sm font-normal text-stone-400">Lots</span>
            </div>
            <span className="text-[10px] text-amber-300 font-medium block mt-1">
              🔐 Cryptographically signed passes
            </span>
          </div>
        </div>
      </div>

      {/* Critical Minerals Strategic Yield Recovery Banner */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-600" />
            <h3 className="font-extrabold text-base text-stone-900">
              Strategic Critical Minerals Retained in Indian Smelting Loop
            </h3>
          </div>
          <span className="text-xs bg-teal-50 text-teal-800 font-bold px-2.5 py-0.5 rounded-full border border-teal-200">
            Import Substitution Value: ~₹48.2 Lakhs
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          <div className="bg-teal-50/60 p-4 rounded-2xl border border-teal-200">
            <span className="text-teal-800 block mb-1 font-bold">Copper (Cu) Recovered</span>
            <div className="text-2xl font-extrabold text-teal-950">{totalCopperKg} kg</div>
            <span className="text-[10px] text-teal-700">Purity Grade: 99.8%</span>
          </div>

          <div className="bg-teal-50/60 p-4 rounded-2xl border border-teal-200">
            <span className="text-teal-800 block mb-1 font-bold">Lithium (Li) Feedstock</span>
            <div className="text-2xl font-extrabold text-teal-950">{totalLithiumKg} kg</div>
            <span className="text-[10px] text-teal-700">EV Battery recycling loop</span>
          </div>

          <div className="bg-teal-50/60 p-4 rounded-2xl border border-teal-200">
            <span className="text-teal-800 block mb-1 font-bold">Cobalt (Co) Feedstock</span>
            <div className="text-2xl font-extrabold text-teal-950">{totalCobaltKg} kg</div>
            <span className="text-[10px] text-teal-700">Cathode precursor grade</span>
          </div>

          <div className="bg-amber-50/80 p-4 rounded-2xl border border-amber-200">
            <span className="text-amber-800 block mb-1 font-bold">Gold (Au Eq.) Recovered</span>
            <div className="text-2xl font-extrabold text-amber-950">{totalGoldGrams} grams</div>
            <span className="text-[10px] text-amber-700">No cyanide acid leaching</span>
          </div>
        </div>
      </div>

      {/* Structured Datasets Explorer & Export Hub (FR-21 / Section 7) */}
      <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-4">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-emerald-600" />
            <div>
              <h3 className="font-extrabold text-base text-stone-900">
                5 Standardized Datasets for Policy & Auditing (Section 7)
              </h3>
              <p className="text-xs text-stone-500">
                Live tabular preview and CSV exports compliant with National Open Data standards
              </p>
            </div>
          </div>

          <button
            onClick={() => exportDatasetToCSV(selectedDatasetTab, { categories, recyclers, lots })}
            className="bg-stone-900 hover:bg-stone-800 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Active Table (.CSV)</span>
          </button>
        </div>

        {/* Dataset Sub-tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs font-bold">
          <button
            onClick={() => setSelectedDatasetTab('materials')}
            className={`px-3 py-2 rounded-xl border shrink-0 transition ${
              selectedDatasetTab === 'materials'
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
            }`}
          >
            1. Material Dataset ({categories.length})
          </button>
          <button
            onClick={() => setSelectedDatasetTab('prices')}
            className={`px-3 py-2 rounded-xl border shrink-0 transition ${
              selectedDatasetTab === 'prices'
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
            }`}
          >
            2. Price Board Dataset
          </button>
          <button
            onClick={() => setSelectedDatasetTab('recyclers')}
            className={`px-3 py-2 rounded-xl border shrink-0 transition ${
              selectedDatasetTab === 'recyclers'
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
            }`}
          >
            3. Recycler Registry ({recyclers.length})
          </button>
          <button
            onClick={() => setSelectedDatasetTab('transactions')}
            className={`px-3 py-2 rounded-xl border shrink-0 transition ${
              selectedDatasetTab === 'transactions'
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
            }`}
          >
            4. Transactions Dataset ({lots.length})
          </button>
          <button
            onClick={() => setSelectedDatasetTab('traceability')}
            className={`px-3 py-2 rounded-xl border shrink-0 transition ${
              selectedDatasetTab === 'traceability'
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
            }`}
          >
            5. EPR Traceability Dataset
          </button>
        </div>

        {/* Dataset Table View */}
        <div className="border border-stone-200 rounded-2xl overflow-x-auto max-h-96">
          {selectedDatasetTab === 'materials' && (
            <table className="w-full text-xs text-left">
              <thead className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200">
                <tr>
                  <th className="p-3">Category ID</th>
                  <th className="p-3">English Name</th>
                  <th className="p-3">Hindi Name</th>
                  <th className="p-3">Formal Rate (₹/kg)</th>
                  <th className="p-3">Informal Baseline</th>
                  <th className="p-3">Price Uplift</th>
                  <th className="p-3">Critical Minerals</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {categories.map((c) => (
                  <tr key={c.id} className="hover:bg-stone-50">
                    <td className="p-3 font-mono font-bold text-stone-900">{c.id}</td>
                    <td className="p-3 font-medium">{c.name.en}</td>
                    <td className="p-3">{c.name.hi}</td>
                    <td className="p-3 font-bold text-emerald-700">₹{c.formalRate}</td>
                    <td className="p-3 line-through text-stone-400">₹{c.informalBaselineRate}</td>
                    <td className="p-3 font-bold text-emerald-600">+{Math.round(((c.formalRate - c.informalBaselineRate) / c.informalBaselineRate) * 100)}%</td>
                    <td className="p-3 text-stone-600">{c.criticalMinerals.join(', ')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {selectedDatasetTab === 'prices' && (
            <table className="w-full text-xs text-left">
              <thead className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200">
                <tr>
                  <th className="p-3">Category</th>
                  <th className="p-3">Benchmark Rate</th>
                  <th className="p-3">Scrap Baseline</th>
                  <th className="p-3">Spread (₹)</th>
                  <th className="p-3">Trend</th>
                  <th className="p-3">Indexed On</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {categories.map((c) => (
                  <tr key={c.id} className="hover:bg-stone-50">
                    <td className="p-3 font-bold text-stone-900">{c.name.en} ({c.id})</td>
                    <td className="p-3 font-bold text-emerald-700">₹{c.formalRate}/{c.unit}</td>
                    <td className="p-3 text-stone-400">₹{c.informalBaselineRate}/{c.unit}</td>
                    <td className="p-3 font-bold text-emerald-600">+₹{c.formalRate - c.informalBaselineRate}</td>
                    <td className="p-3 font-bold text-emerald-700">UP (+{c.trendPercent}%)</td>
                    <td className="p-3 text-stone-500 font-mono">{new Date().toLocaleDateString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {selectedDatasetTab === 'recyclers' && (
            <table className="w-full text-xs text-left">
              <thead className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200">
                <tr>
                  <th className="p-3">Recycler Name</th>
                  <th className="p-3">CPCB Auth Number</th>
                  <th className="p-3">City / State</th>
                  <th className="p-3">Pickup</th>
                  <th className="p-3">Rating</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {recyclers.map((r) => (
                  <tr key={r.id} className="hover:bg-stone-50">
                    <td className="p-3 font-bold text-stone-900">{r.name}</td>
                    <td className="p-3 font-mono text-emerald-800 font-bold">{r.authorizationNumber}</td>
                    <td className="p-3">{r.location.city}, {r.location.state}</td>
                    <td className="p-3 font-bold">{r.pickupAvailable ? '✅ Yes' : '❌ No'}</td>
                    <td className="p-3 font-bold text-amber-600">★ {r.rating}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {selectedDatasetTab === 'transactions' && (
            <table className="w-full text-xs text-left">
              <thead className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200">
                <tr>
                  <th className="p-3">Reference ID</th>
                  <th className="p-3">Collector</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Weight (kg)</th>
                  <th className="p-3">Value (₹)</th>
                  <th className="p-3">Uplift</th>
                  <th className="p-3">Mode</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {lots.map((l) => (
                  <tr key={l.id} className="hover:bg-stone-50">
                    <td className="p-3 font-mono font-bold text-stone-900">{l.referenceCode}</td>
                    <td className="p-3">{l.collectorName}</td>
                    <td className="p-3 font-semibold">{l.materialCategory.toUpperCase()}</td>
                    <td className="p-3 font-bold">{l.actualWeightKg || l.estimatedWeightKg}</td>
                    <td className="p-3 font-bold text-emerald-700">₹{(l.finalSaleValue || l.estimatedValue).toLocaleString('en-IN')}</td>
                    <td className="p-3 font-bold text-emerald-600">+₹{l.priceUplift}</td>
                    <td className="p-3">{l.paymentMode}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        l.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {l.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {selectedDatasetTab === 'traceability' && (
            <table className="w-full text-xs text-left">
              <thead className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200">
                <tr>
                  <th className="p-3">Lot Code</th>
                  <th className="p-3">PIN</th>
                  <th className="p-3">GPS Location Tag</th>
                  <th className="p-3">Recycler Entity</th>
                  <th className="p-3">Traceability Hash (EPR Signed)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {lots.map((l) => (
                  <tr key={l.id} className="hover:bg-stone-50">
                    <td className="p-3 font-mono font-bold text-stone-900">{l.referenceCode}</td>
                    <td className="p-3 font-mono font-bold text-emerald-700">{l.handoverPin}</td>
                    <td className="p-3 text-stone-600">{l.gpsLocation.address}</td>
                    <td className="p-3 font-semibold">{l.matchedRecyclerName || 'Unassigned'}</td>
                    <td className="p-3 font-mono text-[11px] text-emerald-800">{l.traceabilityHash || 'EPR-PENDING-SIGNATURE'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* AI Anomaly Detection & Fraud Prevention Module (FR-19) */}
      <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-600" />
            <h3 className="font-extrabold text-base text-stone-900">
              Audit & AI Anomaly Detection Monitor (FR-19)
            </h3>
          </div>
          <span className="text-xs bg-amber-50 text-amber-800 font-bold px-2 py-0.5 rounded-full border border-amber-200">
            {anomalyLots.length} Flagged Events
          </span>
        </div>

        <div className="divide-y divide-stone-200 border border-stone-200 rounded-2xl">
          {anomalyLots.map((l) => (
            <div key={l.id} className="p-4 bg-amber-50/40 hover:bg-amber-50/80 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-stone-900">{l.referenceCode}</span>
                  <span className="bg-amber-200 text-amber-900 font-bold px-1.5 py-0.5 rounded text-[10px]">
                    FLAGGED FOR WEIGHT AUDIT
                  </span>
                </div>
                <p className="text-stone-700">
                  Collector {l.collectorName} submitted an unusually large lot of <span className="font-bold">{l.estimatedWeightKg} kg</span> ({l.materialCategory.toUpperCase()})
                </p>
                <p className="text-stone-500 font-mono text-[11px]">Location: {l.gpsLocation.address}</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => alert(`Audit verification report requested for lot ${l.referenceCode}`)}
                  className="bg-stone-900 hover:bg-stone-800 text-white font-bold px-3 py-1.5 rounded-lg text-xs"
                >
                  Inspect Chain of Custody
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
