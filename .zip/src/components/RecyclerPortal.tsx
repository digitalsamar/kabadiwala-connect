import React, { useState } from 'react';
import { Recycler, LotRecord, MaterialCategoryInfo, Language, PaymentMode } from '../types';
import { getTranslation } from '../data/translations';
import { speechAssistant } from '../utils/speech';
import confetti from 'canvas-confetti';
import { 
  Building2, 
  ShieldCheck, 
  CheckCircle, 
  XCircle, 
  MapPin, 
  Scale, 
  KeyRound, 
  QrCode, 
  Coins, 
  TrendingUp, 
  Truck, 
  Clock, 
  AlertCircle, 
  ArrowRight,
  Sparkles,
  Phone,
  FileCheck
} from 'lucide-react';

interface RecyclerPortalProps {
  recyclers: Recycler[];
  lots: LotRecord[];
  categories: MaterialCategoryInfo[];
  language: Language;
  onLotUpdated: (lotId: string, status: LotRecord['status'], paymentMode?: PaymentMode, paymentStatus?: LotRecord['paymentStatus'], actualWeightKg?: number, finalSaleValue?: number) => void;
  onUpdateRates: (recyclerId: string, rates: Partial<Record<string, number>>) => void;
}

export const RecyclerPortal: React.FC<RecyclerPortalProps> = ({
  recyclers,
  lots,
  categories,
  language,
  onLotUpdated,
  onUpdateRates,
}) => {
  const t = getTranslation(language);
  const [activeRecycler, setActiveRecycler] = useState<Recycler>(recyclers[0]);
  const [pinInput, setPinInput] = useState<string>('');
  const [verificationError, setVerificationError] = useState<string>('');
  const [verifiedLot, setVerifiedLot] = useState<LotRecord | null>(null);
  const [weighbridgeInput, setWeighbridgeInput] = useState<number>(0);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState<PaymentMode>('CASH');
  const [isConfirmedSuccess, setIsConfirmedSuccess] = useState<boolean>(false);

  // Incoming pending lots matched to this recycler or awaiting verification
  const incomingLots = lots.filter(
    (l) => l.status === 'MATCHED' || l.status === 'IN_TRANSIT' || l.status === 'DRAFT'
  );

  const completedLots = lots.filter((l) => l.status === 'COMPLETED');

  // Verify PIN
  const handleVerifyPin = () => {
    setVerificationError('');
    if (!pinInput || pinInput.length < 4) {
      setVerificationError('Please enter a valid 6-digit collector PIN.');
      return;
    }

    const matched = lots.find((l) => l.handoverPin === pinInput.trim());
    if (!matched) {
      setVerificationError('PIN not found. Check collector handover pass.');
      speechAssistant.speak('पिन नहीं मिला। कृपया कलेक्टर का कोड दोबारा जांचें।', language);
      return;
    }

    setVerifiedLot(matched);
    setWeighbridgeInput(matched.estimatedWeightKg);
    speechAssistant.speak(
      language === 'hi' 
        ? `लॉट मिल गया! ${matched.materialCategory} वजन ${matched.estimatedWeightKg} किलो।`
        : `Lot verified! Weight is ${matched.estimatedWeightKg} kilograms.`,
      language
    );
  };

  // Complete Handover
  const handleCompleteHandover = () => {
    if (!verifiedLot) return;

    const rate = verifiedLot.formalRatePerKg;
    const finalVal = Math.round(weighbridgeInput * rate);

    onLotUpdated(
      verifiedLot.id,
      'COMPLETED',
      selectedPaymentMode,
      selectedPaymentMode === 'CASH' ? 'PAID_CASH' : 'PAID_UPI',
      weighbridgeInput,
      finalVal
    );

    setIsConfirmedSuccess(true);
    try {
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    } catch {}

    const successMsg = language === 'hi'
      ? `हस्तांतरण पूरा हुआ! ₹${finalVal} का भुगतान दर्ज हो गया और EPR सर्टिफिकेट जारी किया गया।`
      : `Handover confirmed! Payout of ₹${finalVal} recorded with EPR certificate.`;
    speechAssistant.speak(successMsg, language);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-12">
      {/* Top Recycler Profile Banner */}
      <div className="bg-gradient-to-r from-stone-900 via-stone-850 to-emerald-950 text-white rounded-3xl p-6 shadow-xl border border-emerald-700/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-800 pb-5">
          <div className="flex items-center gap-3.5">
            <div className="w-13 h-13 rounded-2xl bg-emerald-600 text-stone-950 flex items-center justify-center font-black text-2xl shadow-lg">
              <Building2 className="w-7 h-7 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-white">{activeRecycler.name}</h2>
                <span className="bg-emerald-500/20 text-emerald-300 text-xs px-2 py-0.5 rounded-full font-bold border border-emerald-500/30 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  CPCB Active
                </span>
              </div>
              <p className="text-xs text-stone-300 mt-0.5">
                License: <span className="font-mono text-emerald-400 font-semibold">{activeRecycler.authorizationNumber}</span> • {activeRecycler.location.city}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-400">Switch Facility:</span>
            <select
              value={activeRecycler.id}
              onChange={(e) => {
                const found = recyclers.find((r) => r.id === e.target.value);
                if (found) setActiveRecycler(found);
              }}
              className="bg-stone-950 border border-stone-700 text-white text-xs font-semibold rounded-xl px-3 py-2 focus:outline-none"
            >
              {recyclers.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.tradeName} ({r.location.city})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Recycler KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-5 text-xs">
          <div className="bg-stone-950/70 p-3.5 rounded-2xl border border-stone-800">
            <span className="text-stone-400 block mb-1">Incoming Lots Queue</span>
            <span className="text-2xl font-extrabold text-amber-400">{incomingLots.length} Lots</span>
          </div>

          <div className="bg-stone-950/70 p-3.5 rounded-2xl border border-stone-800">
            <span className="text-stone-400 block mb-1">Compliant Handovers Closed</span>
            <span className="text-2xl font-extrabold text-emerald-400">{completedLots.length} Done</span>
          </div>

          <div className="bg-stone-950/70 p-3.5 rounded-2xl border border-stone-800">
            <span className="text-stone-400 block mb-1">Pickup Fleet Status</span>
            <span className="text-sm font-bold text-white flex items-center gap-1.5 mt-1">
              <Truck className="w-4 h-4 text-emerald-400" />
              {activeRecycler.pickupAvailable ? 'Active (Nagpur Zone)' : 'Drop-off only'}
            </span>
          </div>

          <div className="bg-stone-950/70 p-3.5 rounded-2xl border border-stone-800">
            <span className="text-stone-400 block mb-1">Audit Compliance Rating</span>
            <span className="text-2xl font-extrabold text-emerald-300">★ {activeRecycler.rating} / 5.0</span>
          </div>
        </div>
      </div>

      {/* Main Terminal Grid: Handover PIN Scanner & Incoming Lots Queue */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Digital Handover Terminal (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-extrabold text-base text-stone-900 flex items-center gap-2">
                  <KeyRound className="w-5 h-5 text-emerald-600" />
                  <span>{t.verifyHandoverTitle}</span>
                </h3>
                <p className="text-xs text-stone-500">{t.enterPinOrScan}</p>
              </div>
              <span className="text-xs bg-emerald-50 text-emerald-700 font-bold px-2.5 py-1 rounded-full border border-emerald-200">
                EPR Chain-of-Custody Mode
              </span>
            </div>

            {/* PIN Entry Box */}
            <div className="space-y-3">
              <label className="text-xs font-bold text-stone-700 block">
                6-Digit Collector Handover PIN / QR Code
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  maxLength={6}
                  placeholder="e.g. 904512"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
                  className="flex-1 text-2xl font-mono font-bold tracking-widest px-4 py-3 bg-stone-50 border-2 border-stone-300 rounded-xl focus:border-emerald-600 focus:outline-none text-center"
                />
                <button
                  onClick={handleVerifyPin}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md transition"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Verify</span>
                </button>
              </div>

              {/* Quick Preset PINs for Demo Testing */}
              <div className="flex items-center gap-2 text-xs text-stone-500 pt-1">
                <span>Try Demo PIN:</span>
                {incomingLots.slice(0, 3).map((l) => (
                  <button
                    key={l.id}
                    onClick={() => {
                      setPinInput(l.handoverPin);
                    }}
                    className="bg-stone-100 hover:bg-stone-200 text-stone-800 font-mono px-2 py-0.5 rounded border border-stone-300 text-[11px] font-bold"
                  >
                    {l.handoverPin} ({l.materialCategory})
                  </button>
                ))}
              </div>

              {verificationError && (
                <p className="text-xs font-semibold text-red-600 flex items-center gap-1 bg-red-50 p-2.5 rounded-lg border border-red-200">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{verificationError}</span>
                </p>
              )}
            </div>

            {/* Verified Lot Confirmation Form */}
            {verifiedLot && (
              <div className="bg-stone-50 rounded-2xl p-5 border-2 border-emerald-500/40 space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={verifiedLot.photoUrl}
                      alt="Verified lot"
                      className="w-14 h-14 rounded-xl object-cover border border-stone-300"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                        {verifiedLot.referenceCode}
                      </span>
                      <h4 className="font-bold text-sm text-stone-900 mt-1">
                        {verifiedLot.collectorName} ({verifiedLot.collectorPhone})
                      </h4>
                      <p className="text-xs text-stone-500">{verifiedLot.materialCategory.toUpperCase()} • {verifiedLot.subCategory}</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                    PIN Matched ✓
                  </span>
                </div>

                {/* Weighbridge Verification Step */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-stone-700 block mb-1 flex items-center gap-1">
                      <Scale className="w-3.5 h-3.5 text-emerald-600" />
                      Weighbridge Scale Reading (kg)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={weighbridgeInput}
                      onChange={(e) => setWeighbridgeInput(parseFloat(e.target.value) || 0)}
                      className="w-full text-lg font-bold px-3 py-2 bg-white border border-stone-300 rounded-xl focus:border-emerald-600 focus:outline-none"
                    />
                    <span className="text-[10px] text-stone-400">Collector estimated: {verifiedLot.estimatedWeightKg} kg</span>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-stone-700 block mb-1">
                      Payment Mode
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedPaymentMode('CASH')}
                        className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                          selectedPaymentMode === 'CASH'
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white text-stone-700 border-stone-300'
                        }`}
                      >
                        💵 Cash
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedPaymentMode('UPI')}
                        className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                          selectedPaymentMode === 'UPI'
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-white text-stone-700 border-stone-300'
                        }`}
                      >
                        ⚡ UPI Instant
                      </button>
                    </div>
                  </div>
                </div>

                {/* Final Realization Total */}
                <div className="bg-emerald-950 text-white p-4 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-emerald-400 block">Total Payout Amount:</span>
                    <span className="text-2xl font-extrabold text-emerald-300 font-display">
                      ₹{Math.round(weighbridgeInput * verifiedLot.formalRatePerKg).toLocaleString('en-IN')}
                    </span>
                    <span className="text-[11px] text-stone-300 block">(@ ₹{verifiedLot.formalRatePerKg}/kg)</span>
                  </div>

                  <button
                    onClick={handleCompleteHandover}
                    className="bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-extrabold px-5 py-3 rounded-xl text-xs flex items-center gap-2 shadow-lg transition transform active:scale-95"
                  >
                    <FileCheck className="w-4 h-4" />
                    <span>Confirm & Issue Certificate</span>
                  </button>
                </div>
              </div>
            )}

            {isConfirmedSuccess && (
              <div className="bg-emerald-900 text-white p-4 rounded-2xl border-2 border-emerald-400 text-xs flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div>
                    <p className="font-bold text-sm">Transaction Closed & EPR Certificate Issued!</p>
                    <p className="text-stone-300 font-mono text-[11px]">Traceability Hash: SHA256-EPR-CPCB-2026-NAG</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setIsConfirmedSuccess(false);
                    setVerifiedLot(null);
                    setPinInput('');
                  }}
                  className="bg-white text-stone-900 px-3 py-1.5 rounded-lg font-bold text-xs"
                >
                  Next Lot
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Incoming Lots Feed (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl border border-stone-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-extrabold text-sm text-stone-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600" />
                <span>Incoming Lots from Field</span>
              </h3>
              <span className="text-xs bg-amber-50 text-amber-800 font-bold px-2 py-0.5 rounded-full border border-amber-200">
                {incomingLots.length} Pending
              </span>
            </div>

            {incomingLots.length === 0 ? (
              <p className="text-xs text-stone-400 text-center py-6">No incoming lots at this moment.</p>
            ) : (
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                {incomingLots.map((lot) => (
                  <div
                    key={lot.id}
                    className="p-3.5 bg-stone-50 hover:bg-stone-100/80 rounded-2xl border border-stone-200 text-xs space-y-2 transition"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <img
                          src={lot.photoUrl}
                          alt="Lot"
                          className="w-10 h-10 rounded-lg object-cover border border-stone-300"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <span className="font-mono font-bold text-stone-900 block">{lot.referenceCode}</span>
                          <span className="text-[11px] text-stone-500">{lot.collectorName}</span>
                        </div>
                      </div>
                      <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[11px]">
                        ₹{lot.estimatedValue}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-stone-600 pt-1 border-t border-stone-200">
                      <span>{lot.materialCategory.toUpperCase()} • {lot.estimatedWeightKg} kg</span>
                      <span className="font-mono text-stone-500">PIN: {lot.handoverPin}</span>
                    </div>

                    <button
                      onClick={() => {
                        setPinInput(lot.handoverPin);
                        handleVerifyPin();
                      }}
                      className="w-full bg-stone-900 hover:bg-stone-800 text-white font-bold py-1.5 rounded-xl text-[11px] transition flex items-center justify-center gap-1"
                    >
                      <span>Process Handover</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
