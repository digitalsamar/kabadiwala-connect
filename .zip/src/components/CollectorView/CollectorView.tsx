import React, { useState } from 'react';
import { MaterialCategoryInfo, Recycler, LotRecord, SafetyGuideline, CollectorProfile, Language } from '../../types';
import { getTranslation } from '../../data/translations';
import { PhotoAndValuation } from './PhotoAndValuation';
import { RecyclerMatcher } from './RecyclerMatcher';
import { PriceBoard } from './PriceBoard';
import { HandoverPass } from './HandoverPass';
import { EarningsLedger } from './EarningsLedger';
import { SafetyGuide } from './SafetyGuide';
import { 
  Camera, 
  Building2, 
  TrendingUp, 
  QrCode, 
  Wallet, 
  ShieldCheck 
} from 'lucide-react';

interface CollectorViewProps {
  categories: MaterialCategoryInfo[];
  recyclers: Recycler[];
  lots: LotRecord[];
  safetyGuidelines: SafetyGuideline[];
  profile: CollectorProfile;
  language: Language;
  isOffline: boolean;
  onLotCreated: (lot: LotRecord) => void;
}

export type CollectorTab = 'new_lot' | 'recyclers' | 'prices' | 'receipt' | 'ledger' | 'safety';

export const CollectorView: React.FC<CollectorViewProps> = ({
  categories,
  recyclers,
  lots,
  safetyGuidelines,
  profile,
  language,
  isOffline,
  onLotCreated,
}) => {
  const t = getTranslation(language);
  const [activeTab, setActiveTab] = useState<CollectorTab>('new_lot');

  return (
    <div className="space-y-6 pb-12">
      {/* Sub-Navigation Bar for Collector Features (Icon-Forward for Low Literacy) */}
      <div className="bg-white rounded-2xl p-1.5 border border-stone-200 shadow-sm max-w-5xl mx-auto overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-1 min-w-max sm:min-w-full">
          <button
            onClick={() => setActiveTab('new_lot')}
            className={`flex-1 flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'new_lot'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-700 hover:bg-stone-100'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>{t.tabNewLot}</span>
          </button>

          <button
            onClick={() => setActiveTab('recyclers')}
            className={`flex-1 flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'recyclers'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-700 hover:bg-stone-100'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>{t.tabRecyclers}</span>
          </button>

          <button
            onClick={() => setActiveTab('prices')}
            className={`flex-1 flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'prices'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-700 hover:bg-stone-100'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>{t.tabPrices}</span>
          </button>

          <button
            onClick={() => setActiveTab('receipt')}
            className={`flex-1 flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'receipt'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-700 hover:bg-stone-100'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>{t.tabReceipt}</span>
          </button>

          <button
            onClick={() => setActiveTab('ledger')}
            className={`flex-1 flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'ledger'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-700 hover:bg-stone-100'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>{t.tabLedger}</span>
          </button>

          <button
            onClick={() => setActiveTab('safety')}
            className={`flex-1 flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'safety'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-700 hover:bg-stone-100'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{t.tabSafety}</span>
          </button>
        </div>
      </div>

      {/* Active Tab Screen */}
      <div>
        {activeTab === 'new_lot' && (
          <PhotoAndValuation
            categories={categories}
            language={language}
            isOffline={isOffline}
            onLotCreated={onLotCreated}
            onNavigateToTab={(tab) => setActiveTab(tab as CollectorTab)}
          />
        )}

        {activeTab === 'recyclers' && (
          <RecyclerMatcher
            recyclers={recyclers}
            categories={categories}
            language={language}
            onSelectRecycler={(rec) => {
              setActiveTab('new_lot');
            }}
          />
        )}

        {activeTab === 'prices' && (
          <PriceBoard
            categories={categories}
            language={language}
          />
        )}

        {activeTab === 'receipt' && (
          <HandoverPass
            lots={lots}
            categories={categories}
            language={language}
            onNavigateToTab={(tab) => setActiveTab(tab as CollectorTab)}
          />
        )}

        {activeTab === 'ledger' && (
          <EarningsLedger
            lots={lots}
            profile={profile}
            language={language}
          />
        )}

        {activeTab === 'safety' && (
          <SafetyGuide
            guidelines={safetyGuidelines}
            language={language}
          />
        )}
      </div>
    </div>
  );
};
