import React, { useState, useRef } from 'react';
import { MaterialCategory, MaterialCategoryInfo, Language, LotRecord } from '../../types';
import { getTranslation } from '../../data/translations';
import { speechAssistant } from '../../utils/speech';
import confetti from 'canvas-confetti';
import { 
  Camera, 
  Upload, 
  Sparkles, 
  AlertTriangle, 
  Volume2, 
  TrendingUp, 
  CheckCircle, 
  ArrowRight,
  ShieldAlert,
  Coins,
  Cpu,
  Cable,
  BatteryCharging,
  Tv,
  Monitor,
  Magnet,
  Layers,
  Scale
} from 'lucide-react';

interface PhotoAndValuationProps {
  categories: MaterialCategoryInfo[];
  language: Language;
  isOffline: boolean;
  onLotCreated: (lot: LotRecord) => void;
  onNavigateToTab: (tab: string) => void;
}

export const PhotoAndValuation: React.FC<PhotoAndValuationProps> = ({
  categories,
  language,
  isOffline,
  onLotCreated,
  onNavigateToTab,
}) => {
  const t = getTranslation(language);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedCategory, setSelectedCategory] = useState<MaterialCategoryInfo>(categories[0]);
  const [weightKg, setWeightKg] = useState<number>(12.5);
  const [lotPhoto, setLotPhoto] = useState<string>(categories[0].sampleImage);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [aiConfidence, setAiConfidence] = useState<number>(94);
  const [subCategoryDesc, setSubCategoryDesc] = useState<string>('High-Grade Server Motherboard & Gold Edge Cards');
  const [isSuccessCreated, setIsSuccessCreated] = useState<boolean>(false);
  const [createdLotCode, setCreatedLotCode] = useState<string>('');

  // Icon mapper helper
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Cpu': return <Cpu className="w-5 h-5 text-emerald-600" />;
      case 'Cable': return <Cable className="w-5 h-5 text-amber-600" />;
      case 'BatteryCharging': return <BatteryCharging className="w-5 h-5 text-red-500" />;
      case 'Tv': return <Tv className="w-5 h-5 text-purple-600" />;
      case 'Monitor': return <Monitor className="w-5 h-5 text-blue-600" />;
      case 'Magnet': return <Magnet className="w-5 h-5 text-orange-600" />;
      default: return <Layers className="w-5 h-5 text-stone-600" />;
    }
  };

  // Calculations
  const formalTotal = Math.round(weightKg * selectedCategory.formalRate);
  const informalTotal = Math.round(weightKg * selectedCategory.informalBaselineRate);
  const priceUplift = formalTotal - informalTotal;
  const upliftPercent = Math.round((priceUplift / (informalTotal || 1)) * 100);

  // Handle Photo Upload / Capture
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;
      setLotPhoto(base64Data);
      classifyImage(base64Data);
    };
    reader.readAsDataURL(file);
  };

  const classifyImage = async (base64String: string) => {
    setIsAnalyzing(true);
    try {
      if (!isOffline) {
        const res = await fetch('/api/classify-material', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ imageBase64: base64String }),
        });
        const data = await res.json();
        if (data.success && data.result) {
          const matched = categories.find((c) => c.id === data.result.category) || categories[0];
          setSelectedCategory(matched);
          setAiConfidence(Math.round((data.result.confidence || 0.92) * 100));
          setSubCategoryDesc(data.result.subCategory || matched.name.en);
          speakValuation(matched, weightKg);
          setIsAnalyzing(false);
          return;
        }
      }
    } catch (err) {
      console.warn('API classification error or offline, using fallback heuristic', err);
    }

    // Local heuristic fallback
    setTimeout(() => {
      setIsAnalyzing(false);
      setAiConfidence(89);
      speakValuation(selectedCategory, weightKg);
    }, 600);
  };

  // Spoken price readout helper
  const speakValuation = (cat: MaterialCategoryInfo, weight: number) => {
    const fTotal = Math.round(weight * cat.formalRate);
    const iTotal = Math.round(weight * cat.informalBaselineRate);
    const uplift = fTotal - iTotal;

    let text = '';
    if (language === 'hi') {
      text = `आपका ${weight} किलो ${cat.name.hi} का पक्का सरकारी दाम ₹${fTotal} है। स्थानीय कबाड़ी से आपको ₹${uplift} ज्यादा मिलेंगे!`;
    } else if (language === 'mr') {
      text = `तुमच्या ${weight} किलो मालाचे अधिकृत मूल्य ₹${fTotal} आहे. जुन्या भावापेक्षा तुम्हाला ₹${uplift} जास्तीचा नफा मिळेल.`;
    } else {
      text = `Your ${weight} kilograms of ${cat.name.en} is valued at ₹${fTotal}. You earn an extra ₹${uplift} direct profit over informal scrap rates.`;
    }

    speechAssistant.speak(text, language);
  };

  // Handle Preset Material Select
  const handleSelectPreset = (cat: MaterialCategoryInfo) => {
    setSelectedCategory(cat);
    setLotPhoto(cat.sampleImage);
    setSubCategoryDesc(cat.subCategories[0] || cat.name.en);
    setAiConfidence(95);
    speakValuation(cat, weightKg);
  };

  // Create Lot Record
  const handleCreateLot = () => {
    const randomPin = Math.floor(100000 + Math.random() * 900000).toString();
    const lotId = `lot-${Date.now().toString().slice(-4)}`;
    const refCode = `KC-2026-NAG-${Math.floor(1000 + Math.random() * 9000)}`;

    const newLot: LotRecord = {
      id: lotId,
      referenceCode: refCode,
      collectorId: 'col-001',
      collectorName: 'Ramesh K. (रमेश भाई)',
      collectorPhone: '+91 98234 11098',
      materialCategory: selectedCategory.id,
      subCategory: subCategoryDesc,
      estimatedWeightKg: weightKg,
      formalRatePerKg: selectedCategory.formalRate,
      informalBaselineRatePerKg: selectedCategory.informalBaselineRate,
      estimatedValue: formalTotal,
      priceUplift: priceUplift,
      photoUrl: lotPhoto,
      gpsLocation: {
        lat: 21.1458,
        lng: 79.0882,
        address: 'Sitabuldi E-Waste Hub, Nagpur',
      },
      createdAt: new Date().toISOString(),
      status: 'MATCHED',
      matchedRecyclerId: 'rec-01',
      matchedRecyclerName: 'EcoRecycle Green Hub (CPCB Auth)',
      handoverPin: randomPin,
      paymentMode: 'CASH',
      paymentStatus: 'PENDING',
      isOfflineCreated: isOffline,
      isSynced: !isOffline,
      notes: `Verified via ${isOffline ? 'Offline Price Cache' : 'Gemini AI Vision'}`,
    };

    onLotCreated(newLot);
    setCreatedLotCode(refCode);
    setIsSuccessCreated(true);

    try {
      confetti({
        particleCount: 75,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {
      // ignore
    }

    const confirmSpeech = 
      language === 'hi' ? `रसीद तैयार हो गई है! पर्ची नंबर ${refCode}। रीसायकलर को 6 अंकों का पिन दिखाएं।` :
      language === 'mr' ? `पावती तयार झाली! क्रमांक ${refCode}। रिसायकलरला पिन दाखवा.` :
      `Handover pass generated! Reference ${refCode}. Show the 6-digit PIN to the recycler.`;

    speechAssistant.speak(confirmSpeech, language);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Success Notification Banner */}
      {isSuccessCreated && (
        <div className="bg-emerald-900/90 border-2 border-emerald-500 text-emerald-50 rounded-2xl p-4 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-center gap-3 text-left">
            <div className="w-12 h-12 rounded-full bg-emerald-500 text-stone-950 flex items-center justify-center font-bold shrink-0">
              <CheckCircle className="w-7 h-7" />
            </div>
            <div>
              <h4 className="font-extrabold text-base text-emerald-200">
                {language === 'hi' ? 'रसीद व गारंटी पास तैयार!' : language === 'mr' ? 'हस्तांतरण पावती तयार झाली!' : 'Handover Pass Created!'}
              </h4>
              <p className="text-xs text-emerald-100">
                ID: <span className="font-mono font-bold text-white bg-emerald-950 px-2 py-0.5 rounded">{createdLotCode}</span> • {selectedCategory.name[language]} ({weightKg} kg)
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => onNavigateToTab('receipt')}
              className="w-full sm:w-auto bg-white text-stone-900 hover:bg-stone-100 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md"
            >
              <span>{language === 'hi' ? 'पर्ची देखें (QR / PIN)' : language === 'mr' ? 'पावती पहा' : 'View Handover Pass'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsSuccessCreated(false)}
              className="text-xs text-emerald-300 hover:text-white px-2 py-1"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main Grid: Photo Capture + Dynamic Price Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Visual Capture & Material Select (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Photo Box */}
          <div className="bg-white rounded-2xl border border-stone-200 p-4 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-sm text-stone-800 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-emerald-600" />
                <span>{t.takePhoto}</span>
              </h3>
              {aiConfidence && (
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-emerald-600" />
                  {aiConfidence}% {t.confidence}
                </span>
              )}
            </div>

            {/* Photo Preview Container */}
            <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-stone-900 group border border-stone-200">
              <img
                src={lotPhoto}
                alt="E-Waste Lot"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />

              {/* Scanning Overlay Effect when analyzing */}
              {isAnalyzing && (
                <div className="absolute inset-0 bg-emerald-950/70 backdrop-blur-xs flex flex-col items-center justify-center text-white p-4">
                  <div className="w-12 h-12 rounded-full border-4 border-emerald-400 border-t-transparent animate-spin mb-3" />
                  <p className="font-bold text-sm text-emerald-200 animate-pulse">{t.classifying}</p>
                  <p className="text-[11px] text-stone-300">Gemini 3.7 Vision • JNARDDC E-Waste Model</p>
                </div>
              )}

              {/* Floating Camera / Upload Action Bar */}
              <div className="absolute bottom-3 inset-x-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1 bg-stone-900/85 hover:bg-stone-900 text-white backdrop-blur-md px-3 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-lg border border-stone-700 transition"
                >
                  <Camera className="w-4 h-4 text-emerald-400" />
                  <span>{language === 'hi' ? 'कैमरा / फोटो लें' : language === 'mr' ? 'फोटो काढा' : 'Take / Upload Photo'}</span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handlePhotoUpload}
                />
              </div>
            </div>

            {/* AI Identified Category Tag */}
            <div className="mt-3 p-3 bg-stone-50 rounded-xl border border-stone-200">
              <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
                <span>{t.classifiedAs}</span>
                <span className="font-mono text-[11px] text-emerald-700 font-semibold">{selectedCategory.id.toUpperCase()}</span>
              </div>
              <p className="font-bold text-sm text-stone-900 flex items-center gap-2">
                {getCategoryIcon(selectedCategory.iconName)}
                <span>{selectedCategory.name[language]}</span>
              </p>
              <p className="text-xs text-stone-600 mt-1 line-clamp-1">{subCategoryDesc}</p>
            </div>
          </div>

          {/* Quick Preset Selector for Low Literacy / Quick One-Tap */}
          <div className="bg-white rounded-2xl border border-stone-200 p-4 shadow-sm">
            <h4 className="font-bold text-xs text-stone-700 uppercase tracking-wider mb-2.5 flex items-center justify-between">
              <span>{t.orSelectPreset}</span>
              <span className="text-[11px] font-normal text-stone-400">(टैप करके चुनें)</span>
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {categories.map((cat) => {
                const isSelected = cat.id === selectedCategory.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => handleSelectPreset(cat)}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all ${
                      isSelected
                        ? 'bg-emerald-50 border-emerald-500 shadow-sm ring-1 ring-emerald-500'
                        : 'bg-stone-50 hover:bg-stone-100 border-stone-200 text-stone-700'
                    }`}
                  >
                    <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-emerald-500 text-white' : 'bg-white text-stone-700 border border-stone-200'}`}>
                      {getCategoryIcon(cat.iconName)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold truncate text-stone-900">{cat.name[language]}</p>
                      <p className="text-[11px] font-semibold text-emerald-700">₹{cat.formalRate}/{cat.unit}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Weight Dial, Value Calculation, & Handover Lock (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Weight Input Box */}
          <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                  <Scale className="w-5 h-5 text-emerald-600" />
                  <span>{t.enterWeight}</span>
                </h3>
                <p className="text-xs text-stone-500">
                  {language === 'hi' ? 'कांटे पर तौल कर वजन डालें' : language === 'mr' ? 'काट्यावरील अचूक वजन टाका' : 'Adjust lot weight using slider or buttons'}
                </p>
              </div>
              <div className="text-right">
                <span className="text-3xl font-extrabold font-display text-emerald-600">{weightKg}</span>
                <span className="text-sm font-bold text-stone-600 ml-1">kg</span>
              </div>
            </div>

            {/* Big Slider */}
            <input
              type="range"
              min="0.5"
              max="150"
              step="0.5"
              value={weightKg}
              onChange={(e) => setWeightKg(parseFloat(e.target.value))}
              className="w-full h-3 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
            />

            {/* Quick Weight Chips for fast field input */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              {[2, 5, 10, 15, 25, 50, 80].map((w) => (
                <button
                  key={w}
                  onClick={() => setWeightKg(w)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition ${
                    weightKg === w
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                      : 'bg-stone-50 hover:bg-stone-100 border-stone-300 text-stone-700'
                  }`}
                >
                  {w} kg
                </button>
              ))}
              <div className="flex items-center gap-1 ml-auto">
                <button
                  onClick={() => setWeightKg((prev) => Math.max(0.5, Math.round((prev - 0.5) * 10) / 10))}
                  className="w-8 h-8 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 font-extrabold flex items-center justify-center text-base"
                >
                  -
                </button>
                <button
                  onClick={() => setWeightKg((prev) => Math.round((prev + 0.5) * 10) / 10)}
                  className="w-8 h-8 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 font-extrabold flex items-center justify-center text-base"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* Real-time Fair Value Comparison Card */}
          <div className="bg-gradient-to-br from-emerald-950 via-stone-900 to-teal-950 text-white rounded-2xl p-5 shadow-lg border border-emerald-600/30 space-y-4">
            <div className="flex items-center justify-between border-b border-emerald-800/60 pb-3">
              <div>
                <span className="text-xs uppercase tracking-wider text-emerald-400 font-bold flex items-center gap-1">
                  <Coins className="w-4 h-4" />
                  {t.estimatedValue}
                </span>
                <div className="text-4xl sm:text-5xl font-extrabold font-display text-emerald-300 tracking-tight mt-1">
                  ₹{formalTotal.toLocaleString('en-IN')}
                </div>
              </div>

              {/* Voice Readout Button */}
              <button
                type="button"
                onClick={() => speakValuation(selectedCategory, weightKg)}
                className="bg-emerald-500 hover:bg-emerald-400 text-stone-950 px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-md transition transform active:scale-95 shrink-0"
              >
                <Volume2 className="w-4 h-4" />
                <span>{t.speakEstimate}</span>
              </button>
            </div>

            {/* Economic Uplift Calculation: Informal vs Kabadiwala Connect */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="bg-stone-900/80 rounded-xl p-3 border border-stone-800">
                <p className="text-[11px] text-stone-400 mb-0.5">{t.informalRate}</p>
                <p className="text-sm font-semibold text-stone-300 line-through">
                  ₹{informalTotal.toLocaleString('en-IN')} <span className="text-xs text-stone-400">(₹{selectedCategory.informalBaselineRate}/kg)</span>
                </p>
                <p className="text-[10px] text-red-400 mt-1">❌ कबाड़ी का सस्ता भाव</p>
              </div>

              <div className="bg-emerald-900/40 rounded-xl p-3 border border-emerald-500/40">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] text-emerald-300 font-bold">{t.yourUplift}</p>
                  <span className="bg-emerald-500 text-stone-950 text-[10px] font-black px-1.5 py-0.2 rounded">
                    +{upliftPercent}%
                  </span>
                </div>
                <p className="text-lg font-extrabold text-emerald-400 mt-0.5">
                  +₹{priceUplift.toLocaleString('en-IN')}
                </p>
                <p className="text-[10px] text-emerald-200/90 mt-0.5">✅ सीधे आपकी जेब में अतिरिक्त मुनाफा</p>
              </div>
            </div>

            {/* Critical Mineral Recovery Yield */}
            <div className="bg-stone-950/60 rounded-xl p-3 border border-stone-800 text-xs">
              <span className="text-stone-400 block text-[11px] mb-1 font-medium">{t.criticalYield}:</span>
              <div className="flex flex-wrap gap-1.5">
                {selectedCategory.criticalMinerals.map((mineral, i) => (
                  <span key={i} className="bg-teal-950 text-teal-300 border border-teal-800 text-[11px] font-semibold px-2 py-0.5 rounded-md">
                    {mineral}
                  </span>
                ))}
              </div>
            </div>

            {/* Hazard Alert Banner */}
            <div className="bg-amber-950/60 border border-amber-500/40 rounded-xl p-3 flex items-start gap-2.5 text-xs text-amber-200">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-amber-300">{t.hazardAlert}: </span>
                <span>{selectedCategory.hazardousRisk}</span>
              </div>
            </div>

            {/* Generate Handover Pass Button */}
            <button
              onClick={handleCreateLot}
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-stone-950 font-extrabold text-sm sm:text-base py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/20 transition transform active:scale-[0.99]"
            >
              <TrendingUp className="w-5 h-5" />
              <span>{t.createLotBtn}</span>
              <ArrowRight className="w-5 h-5 ml-1" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
