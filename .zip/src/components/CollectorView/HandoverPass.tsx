import React, { useState } from 'react';
import { LotRecord, Language, MaterialCategoryInfo } from '../../types';
import { getTranslation } from '../../data/translations';
import { speechAssistant } from '../../utils/speech';
import { 
  QrCode, 
  ShieldCheck, 
  MapPin, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Share2, 
  Download, 
  Scale, 
  Coins, 
  Volume2, 
  ArrowRight,
  Sparkles,
  Lock,
  KeyRound
} from 'lucide-react';

interface HandoverPassProps {
  lots: LotRecord[];
  categories: MaterialCategoryInfo[];
  language: Language;
  onNavigateToTab: (tab: string) => void;
}

export const HandoverPass: React.FC<HandoverPassProps> = ({
  lots,
  categories,
  language,
  onNavigateToTab,
}) => {
  const t = getTranslation(language);
  const [selectedLotId, setSelectedLotId] = useState<string>(lots[0]?.id || '');

  const activeLot = lots.find((l) => l.id === selectedLotId) || lots[0];

  if (!activeLot) {
    return (
      <div className="bg-white rounded-2xl p-8 text-center border border-stone-200 shadow-sm max-w-lg mx-auto">
        <QrCode className="w-12 h-12 text-stone-400 mx-auto mb-3" />
        <h3 className="font-bold text-base text-stone-800">
          {language === 'hi' ? 'कोई सक्रिय पर्ची नहीं है' : language === 'mr' ? 'कोणतीही पावती उपलब्ध नाही' : 'No Active Handover Pass'}
        </h3>
        <p className="text-xs text-stone-500 mt-1 mb-4">
          {language === 'hi' ? 'पहले फोटो खींचकर नया लॉट तैयार करें।' : language === 'mr' ? 'प्रथम फोटो काढून नवीन लॉट तयार करा.' : 'Create a new lot by photographing your scrap lot.'}
        </p>
        <button
          onClick={() => onNavigateToTab('new_lot')}
          className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-md"
        >
          {t.tabNewLot}
        </button>
      </div>
    );
  }

  const categoryInfo = categories.find((c) => c.id === activeLot.materialCategory) || categories[0];

  const speakPinAndPass = () => {
    let text = '';
    if (language === 'hi') {
      text = `आपकी पर्ची संख्या ${activeLot.referenceCode} है। रीसायकलर को देने वाला गुप्त पिन है: ${activeLot.handoverPin.split('').join(' ')}। कुल अनुमानित रकम ₹${activeLot.estimatedValue} है।`;
    } else if (language === 'mr') {
      text = `तुमचा पावती क्रमांक ${activeLot.referenceCode} आहे. रिसायकलरला द्यायचा पिन आहे: ${activeLot.handoverPin.split('').join(' ')}। अंदाजे रक्कम ₹${activeLot.estimatedValue} आहे.`;
    } else {
      text = `Your handover pass ID is ${activeLot.referenceCode}. The 6-digit offline confirmation PIN is ${activeLot.handoverPin.split('').join(' ')}. Total estimated payout is ₹${activeLot.estimatedValue}.`;
    }
    speechAssistant.speak(text, language);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Lots Selector if multiple exist */}
      {lots.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          {lots.map((lot) => {
            const isSelected = lot.id === activeLot.id;
            return (
              <button
                key={lot.id}
                onClick={() => setSelectedLotId(lot.id)}
                className={`px-3 py-2 rounded-xl text-xs font-bold border shrink-0 transition flex items-center gap-2 ${
                  isSelected
                    ? 'bg-stone-900 text-white border-stone-900 shadow-sm'
                    : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                }`}
              >
                <span className="font-mono">{lot.referenceCode}</span>
                <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                  lot.status === 'COMPLETED' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-300'
                }`}>
                  {lot.status}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Main Chain-of-Custody Digital Pass Certificate */}
      <div className="bg-white rounded-3xl border-2 border-stone-800 shadow-xl overflow-hidden">
        {/* Top Header Strip */}
        <div className="bg-stone-900 text-white p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 text-stone-950 flex items-center justify-center font-extrabold text-lg shadow-md">
              EPR
            </div>
            <div>
              <span className="text-[10px] font-bold tracking-wider uppercase text-emerald-400 block">
                Ministry of Mines / JNARDDC Handover Pass
              </span>
              <h2 className="text-lg font-extrabold font-display text-white tracking-tight flex items-center gap-2">
                <span>{activeLot.referenceCode}</span>
                {activeLot.status === 'COMPLETED' ? (
                  <span className="text-xs bg-emerald-500 text-stone-950 px-2 py-0.5 rounded-full font-black">
                    COMPLETED & PAID
                  </span>
                ) : (
                  <span className="text-xs bg-amber-400 text-stone-950 px-2 py-0.5 rounded-full font-bold">
                    PENDING HANDOVER
                  </span>
                )}
              </h2>
            </div>
          </div>

          <button
            onClick={speakPinAndPass}
            className="bg-emerald-500 hover:bg-emerald-400 text-stone-950 px-3.5 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md transition transform active:scale-95"
          >
            <Volume2 className="w-4 h-4" />
            <span>{language === 'hi' ? 'पिन व विवरण सुनो' : language === 'mr' ? 'पिन ऐका' : 'Speak PIN & Pass'}</span>
          </button>
        </div>

        {/* Certificate Body */}
        <div className="p-5 sm:p-7 space-y-6">
          {/* Visual QR & 6-Digit PIN Highlight */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center bg-stone-50 rounded-2xl p-5 border border-stone-200">
            {/* Simulated Dynamic QR Code */}
            <div className="md:col-span-4 flex flex-col items-center justify-center text-center p-3 bg-white rounded-xl border border-stone-200 shadow-sm">
              <div className="relative p-2 bg-stone-950 rounded-lg">
                {/* SVG QR Code Pattern */}
                <svg viewBox="0 0 100 100" className="w-28 h-28 text-white fill-current">
                  <rect width="100" height="100" fill="white" />
                  {/* Position squares */}
                  <rect x="10" y="10" width="30" height="30" fill="#09090b" />
                  <rect x="15" y="15" width="20" height="20" fill="white" />
                  <rect x="20" y="20" width="10" height="10" fill="#09090b" />

                  <rect x="60" y="10" width="30" height="30" fill="#09090b" />
                  <rect x="65" y="15" width="20" height="20" fill="white" />
                  <rect x="70" y="20" width="10" height="10" fill="#09090b" />

                  <rect x="10" y="60" width="30" height="30" fill="#09090b" />
                  <rect x="15" y="65" width="20" height="20" fill="white" />
                  <rect x="20" y="70" width="10" height="10" fill="#09090b" />

                  {/* QR Data Dots */}
                  <rect x="45" y="15" width="8" height="8" fill="#10b981" />
                  <rect x="45" y="30" width="8" height="8" fill="#09090b" />
                  <rect x="15" y="45" width="8" height="8" fill="#09090b" />
                  <rect x="30" y="45" width="8" height="8" fill="#10b981" />
                  <rect x="45" y="45" width="10" height="10" fill="#09090b" />
                  <rect x="60" y="45" width="8" height="8" fill="#09090b" />
                  <rect x="75" y="45" width="8" height="8" fill="#10b981" />
                  <rect x="45" y="60" width="8" height="8" fill="#09090b" />
                  <rect x="60" y="60" width="10" height="10" fill="#09090b" />
                  <rect x="75" y="75" width="10" height="10" fill="#09090b" />
                  <rect x="45" y="75" width="8" height="8" fill="#10b981" />
                </svg>
              </div>
              <span className="text-[10px] text-stone-500 font-semibold mt-2">
                Scan via Recycler App
              </span>
            </div>

            {/* 6-Digit Verification PIN (FR-6 Offline tolerance) */}
            <div className="md:col-span-8 space-y-3">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-emerald-600" />
                <div>
                  <h3 className="font-bold text-sm text-stone-900">{t.handoverPin}</h3>
                  <p className="text-xs text-stone-500">{t.showToRecycler}</p>
                </div>
              </div>

              {/* Big PIN Display */}
              <div className="flex items-center gap-2">
                {activeLot.handoverPin.split('').map((digit, i) => (
                  <div
                    key={i}
                    className="w-11 h-13 sm:w-13 sm:h-15 rounded-xl bg-white border-2 border-emerald-600 text-stone-950 font-display font-extrabold text-2xl sm:text-3xl flex items-center justify-center shadow-sm"
                  >
                    {digit}
                  </div>
                ))}
              </div>

              <p className="text-[11px] text-stone-500 font-medium">
                🔒 {language === 'hi' 
                  ? 'यह 6-अंकों का कोड बिना इंटरनेट (ऑफलाइन) भी रीसायकलर के फोन में काम करता है।' 
                  : language === 'mr'
                  ? 'हा ६-अंकी कोड इंटरनेट नसतानाही काम करतो.'
                  : 'This 6-digit PIN validates the handover tamper-proof even with zero connectivity.'}
              </p>
            </div>
          </div>

          {/* Lot Details Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-stone-50 p-3 rounded-xl border border-stone-200">
              <span className="text-stone-500 block mb-0.5 font-medium">Material Type:</span>
              <span className="font-bold text-stone-900 text-sm">{categoryInfo.name[language]}</span>
            </div>

            <div className="bg-stone-50 p-3 rounded-xl border border-stone-200">
              <span className="text-stone-500 block mb-0.5 font-medium">Lot Weight:</span>
              <span className="font-bold text-stone-900 text-sm">{activeLot.actualWeightKg || activeLot.estimatedWeightKg} kg</span>
            </div>

            <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200">
              <span className="text-emerald-800 block mb-0.5 font-medium">Locked Formal Rate:</span>
              <span className="font-bold text-emerald-800 text-sm">₹{activeLot.formalRatePerKg}/kg</span>
            </div>

            <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200">
              <span className="text-emerald-800 block mb-0.5 font-medium">Total Payout:</span>
              <span className="font-extrabold text-emerald-900 text-base">₹{(activeLot.finalSaleValue || activeLot.estimatedValue).toLocaleString('en-IN')}</span>
            </div>
          </div>

          {/* Traceability Metadata Bar */}
          <div className="bg-stone-900 text-stone-300 rounded-2xl p-4 text-xs space-y-2 font-mono">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-800 pb-2">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                {activeLot.gpsLocation.address} ({activeLot.gpsLocation.lat.toFixed(4)}, {activeLot.gpsLocation.lng.toFixed(4)})
              </span>
              <span className="flex items-center gap-1.5 text-stone-400">
                <Clock className="w-3.5 h-3.5" />
                {new Date(activeLot.createdAt).toLocaleString('en-IN')}
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px]">
              <div>
                <span className="text-stone-400">Matched Recycler: </span>
                <span className="text-white font-bold">{activeLot.matchedRecyclerName || 'EcoRecycle Hub (Nagpur)'}</span>
              </div>
              <div>
                <span className="text-stone-400">Traceability Hash: </span>
                <span className="text-emerald-400 font-bold">{activeLot.traceabilityHash || 'EPR-PENDING-HASH'}</span>
              </div>
            </div>
          </div>

          {/* Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <button
              onClick={() => {
                alert(`Receipt pass for ${activeLot.referenceCode} saved to phone!`);
              }}
              className="bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold py-2.5 px-4 rounded-xl flex items-center gap-1.5 transition"
            >
              <Download className="w-4 h-4" />
              <span>{t.downloadSlip}</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigateToTab('ledger')}
                className="bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold py-2.5 px-4 rounded-xl flex items-center gap-1.5 shadow-sm transition"
              >
                <span>{t.tabLedger}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
