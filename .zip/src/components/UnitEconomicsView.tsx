import React, { useState } from 'react';
import { Language } from '../types';
import { getTranslation } from '../data/translations';
import { 
  Coins, 
  TrendingUp, 
  ShieldCheck, 
  Scale, 
  Sparkles, 
  AlertTriangle, 
  ArrowRight, 
  CheckCircle2, 
  Building2, 
  Truck 
} from 'lucide-react';

interface UnitEconomicsViewProps {
  language: Language;
}

export const UnitEconomicsView: React.FC<UnitEconomicsViewProps> = ({ language }) => {
  const t = getTranslation(language);
  const [simulatedPcbKg, setSimulatedPcbKg] = useState<number>(30);
  const [simulatedWireKg, setSimulatedWireKg] = useState<number>(45);
  const [simulatedBatteryKg, setSimulatedBatteryKg] = useState<number>(20);

  // Economic calculations
  const formalRatePcb = 480;
  const informalRatePcb = 210;

  const formalRateWire = 340;
  const informalRateWire = 160;

  const formalRateBattery = 190;
  const informalRateBattery = 75;

  const informalTotal = 
    simulatedPcbKg * informalRatePcb + 
    simulatedWireKg * informalRateWire + 
    simulatedBatteryKg * informalRateBattery;

  const formalTotal = 
    simulatedPcbKg * formalRatePcb + 
    simulatedWireKg * formalRateWire + 
    simulatedBatteryKg * formalRateBattery;

  const netExtraIncome = formalTotal - informalTotal;
  const percentGain = Math.round((netExtraIncome / (informalTotal || 1)) * 100);

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950 via-stone-900 to-stone-900 text-white rounded-3xl p-6 shadow-xl border border-amber-600/40">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-extrabold text-lg shadow-md">
            ₹
          </div>
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
              Section 6: Economic Viability & Incentive Alignment
            </span>
            <h2 className="text-xl font-extrabold text-white">
              {language === 'hi' ? 'कलेक्टर व रीसायकलर का पक्का आर्थिक फायदा' : language === 'mr' ? 'आर्थिक लाभ विश्लेषण' : 'Unit Economics & Fair Value Realization'}
            </h2>
          </div>
        </div>
        <p className="text-xs text-stone-300 max-w-2xl leading-relaxed">
          {language === 'hi'
            ? 'कबाड़ीवाला कनेक्ट अनौपचारिक कबाड़ी को बिना किसी जुर्माने के सीधे 100% से 150% अधिक कमाई का अवसर देता है, जिससे हानिकारक आग लगाने और तेजाब धोने की कुप्रथा स्वतः बंद हो जाती है।'
            : 'By bypassing backyard middlemen and connecting collectors directly to CPCB-authorized smelters with EPR credit incentives, collectors double their take-home income while keeping hazardous toxins out of groundwater.'}
        </p>
      </div>

      {/* Live Interactive Collector Monthly Income Simulator */}
      <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-sm space-y-5">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-emerald-600" />
            <h3 className="font-extrabold text-base text-stone-900">
              {language === 'hi' ? 'मासिक अतिरिक्त कमाई कैलकुलेटर' : language === 'mr' ? 'मासिक नफा गणक' : 'Simulate Collector Monthly Income Uplift'}
            </h3>
          </div>
          <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
            Real Market Spreads
          </span>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-700">सर्किट बोर्ड (PCBs):</span>
              <span className="text-sm font-extrabold font-display text-emerald-700">{simulatedPcbKg} kg</span>
            </div>
            <input
              type="range"
              min="0"
              max="150"
              value={simulatedPcbKg}
              onChange={(e) => setSimulatedPcbKg(parseInt(e.target.value))}
              className="w-full h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
            />
            <div className="flex items-center justify-between text-[11px] text-stone-500 pt-1">
              <span>कबाड़ी: ₹{informalRatePcb}/kg</span>
              <span className="font-bold text-emerald-700">पक्का: ₹{formalRatePcb}/kg</span>
            </div>
          </div>

          <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-700">तांबे के तार (Cables):</span>
              <span className="text-sm font-extrabold font-display text-emerald-700">{simulatedWireKg} kg</span>
            </div>
            <input
              type="range"
              min="0"
              max="200"
              value={simulatedWireKg}
              onChange={(e) => setSimulatedWireKg(parseInt(e.target.value))}
              className="w-full h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
            />
            <div className="flex items-center justify-between text-[11px] text-stone-500 pt-1">
              <span>कबाड़ी: ₹{informalRateWire}/kg</span>
              <span className="font-bold text-emerald-700">पक्का: ₹{formalRateWire}/kg</span>
            </div>
          </div>

          <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-700">बैटरियां (Batteries):</span>
              <span className="text-sm font-extrabold font-display text-emerald-700">{simulatedBatteryKg} kg</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={simulatedBatteryKg}
              onChange={(e) => setSimulatedBatteryKg(parseInt(e.target.value))}
              className="w-full h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
            />
            <div className="flex items-center justify-between text-[11px] text-stone-500 pt-1">
              <span>कबाड़ी: ₹{informalRateBattery}/kg</span>
              <span className="font-bold text-emerald-700">पक्का: ₹{formalRateBattery}/kg</span>
            </div>
          </div>
        </div>

        {/* Realization Banner */}
        <div className="bg-gradient-to-br from-emerald-950 via-stone-900 to-teal-950 text-white rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-emerald-500/40">
          <div className="space-y-1">
            <span className="text-xs text-emerald-300 font-bold uppercase tracking-wider block">
              सीधा शुद्ध अतिरिक्त मुनाफा (Net Profit Uplift)
            </span>
            <div className="text-3xl sm:text-4xl font-extrabold font-display text-emerald-300">
              +₹{netExtraIncome.toLocaleString('en-IN')}{' '}
              <span className="text-base font-semibold text-emerald-400">(+{percentGain}%)</span>
            </div>
            <p className="text-xs text-stone-300">
              अनौपचारिक कबाड़ी से कमाई: <span className="line-through text-stone-400">₹{informalTotal.toLocaleString('en-IN')}</span> ➔ कबाडीवाला कनेक्ट कमाई: <span className="font-bold text-emerald-400">₹{formalTotal.toLocaleString('en-IN')}</span>
            </p>
          </div>

          <div className="bg-emerald-900/60 border border-emerald-400/40 p-3.5 rounded-xl text-xs space-y-1">
            <span className="font-bold text-emerald-200 block">पारिवारिक प्रभाव:</span>
            <p className="text-emerald-100">
              यह अतिरिक्त ₹{netExtraIncome.toLocaleString('en-IN')} राशि बच्चों की स्कूल फीस व स्वास्थ्य सुरक्षा के बराबर है।
            </p>
          </div>
        </div>
      </div>

      {/* Stakeholder Comparison Matrix (Section 6 Table) */}
      <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-sm space-y-4">
        <h3 className="font-extrabold text-base text-stone-900 flex items-center gap-2">
          <Scale className="w-5 h-5 text-stone-700" />
          <span>Systemic Comparison: Backyard Informal vs Kabadiwala Connect</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-stone-100 text-stone-800 font-bold">
              <tr>
                <th className="p-3">Stakeholder</th>
                <th className="p-3 text-red-700">Baseline: Informal Backyard Scrap</th>
                <th className="p-3 text-emerald-800">Formal: Kabadiwala Connect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200">
              <tr className="hover:bg-stone-50">
                <td className="p-3 font-bold text-stone-900">Informal Collector</td>
                <td className="p-3 text-red-900 bg-red-50/40">
                  • Low rates (₹160-210/kg)<br />
                  • Extreme toxic smoke inhalation (burning)<br />
                  • Vulnerable to local harassment & non-payment
                </td>
                <td className="p-3 text-emerald-950 bg-emerald-50/40 font-semibold">
                  • 100-150% higher payout (₹340-480/kg)<br />
                  • Zero burning/leaching required<br />
                  • Instant cash/UPI guarantee with CPCB pass
                </td>
              </tr>

              <tr className="hover:bg-stone-50">
                <td className="p-3 font-bold text-stone-900">Authorized Recycler</td>
                <td className="p-3 text-red-900 bg-red-50/40">
                  • Severe feedstock shortage<br />
                  • Inability to fulfill EPR compliance targets<br />
                  • Damaged/burnt material with low recovery yield
                </td>
                <td className="p-3 text-emerald-950 bg-emerald-50/40 font-semibold">
                  • Consistent last-mile collection feed<br />
                  • Tamper-evident EPR traceability records<br />
                  • Intact components yielding high-grade minerals
                </td>
              </tr>

              <tr className="hover:bg-stone-50">
                <td className="p-3 font-bold text-stone-900">Ministry of Mines / Nation</td>
                <td className="p-3 text-red-900 bg-red-50/40">
                  • Critical minerals lost to ash & acid pits<br />
                  • Massive public healthcare burden<br />
                  • Heavy reliance on imported virgin metals
                </td>
                <td className="p-3 text-emerald-950 bg-emerald-50/40 font-semibold">
                  • 99%+ Lithium, Cobalt & Neodymium retention<br />
                  • Clean circular economy in line with 2022 E-Waste Rules<br />
                  • Inclusive informal sector formalization without force
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
