import React, { useState, useEffect } from 'react';
import { 
  UserRole, 
  Language, 
  LotRecord, 
  PaymentMode, 
  Recycler, 
  MaterialCategoryInfo, 
  SafetyGuideline, 
  CollectorProfile 
} from './types';
import { 
  MATERIAL_CATEGORIES, 
  INITIAL_RECYCLERS, 
  INITIAL_LOTS, 
  INITIAL_SAFETY_GUIDELINES, 
  INITIAL_COLLECTOR_PROFILE 
} from './data/initialData';
import { OfflineStore } from './utils/offlineStore';
import { Header } from './components/Header';
import { CollectorView } from './components/CollectorView/CollectorView';
import { RecyclerPortal } from './components/RecyclerPortal';
import { AdminDashboard } from './components/AdminDashboard';
import { UnitEconomicsView } from './components/UnitEconomicsView';

export default function App() {
  const [role, setRole] = useState<UserRole>('collector');
  const [language, setLanguage] = useState<Language>('hi');
  const [isOffline, setIsOffline] = useState<boolean>(OfflineStore.isForcedOffline());
  const [pendingSyncCount, setPendingSyncCount] = useState<number>(0);

  // Core app state initialized from OfflineStore
  const [categories, setCategories] = useState<MaterialCategoryInfo[]>(() => OfflineStore.getCategories());
  const [recyclers, setRecyclers] = useState<Recycler[]>(() => OfflineStore.getRecyclers());
  const [lots, setLots] = useState<LotRecord[]>(() => OfflineStore.getLots());
  const [safetyGuidelines] = useState<SafetyGuideline[]>(INITIAL_SAFETY_GUIDELINES);
  const [collectorProfile, setCollectorProfile] = useState<CollectorProfile>(() => OfflineStore.getCollectorProfile());

  // Listen to offline store updates
  useEffect(() => {
    const refreshState = () => {
      setLots(OfflineStore.getLots());
      setRecyclers(OfflineStore.getRecyclers());
      setCategories(OfflineStore.getCategories());
      setCollectorProfile(OfflineStore.getCollectorProfile());
      setPendingSyncCount(OfflineStore.getPendingSyncLots().length);
    };

    refreshState();
    const unsubscribe = OfflineStore.subscribe(refreshState);
    return () => unsubscribe();
  }, []);

  // Handle new lot creation
  const handleLotCreated = (newLot: LotRecord) => {
    OfflineStore.saveLot(newLot);
  };

  // Handle lot status / payment updates by recyclers
  const handleLotUpdated = (
    lotId: string, 
    status: LotRecord['status'], 
    paymentMode?: PaymentMode, 
    paymentStatus?: LotRecord['paymentStatus'], 
    actualWeightKg?: number, 
    finalSaleValue?: number
  ) => {
    OfflineStore.updateLotStatus(lotId, status, paymentMode, paymentStatus, actualWeightKg, finalSaleValue);
  };

  // Handle recycler rate updates
  const handleUpdateRates = (recyclerId: string, rates: Partial<Record<string, number>>) => {
    OfflineStore.updateRecyclerRates(recyclerId, rates);
  };

  return (
    <div className="min-h-screen bg-stone-100 text-stone-900 flex flex-col font-sans antialiased selection:bg-emerald-500 selection:text-stone-950">
      {/* Universal Top Header */}
      <Header
        currentRole={role}
        setRole={setRole}
        language={language}
        setLanguage={setLanguage}
        isOffline={isOffline}
        setIsOffline={setIsOffline}
        pendingSyncCount={pendingSyncCount}
        onSyncComplete={() => {
          setLots(OfflineStore.getLots());
          setPendingSyncCount(0);
        }}
      />

      {/* Main Content View Switcher */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {role === 'collector' && (
          <CollectorView
            categories={categories}
            recyclers={recyclers}
            lots={lots}
            safetyGuidelines={safetyGuidelines}
            profile={collectorProfile}
            language={language}
            isOffline={isOffline}
            onLotCreated={handleLotCreated}
          />
        )}

        {role === 'recycler' && (
          <RecyclerPortal
            recyclers={recyclers}
            lots={lots}
            categories={categories}
            language={language}
            onLotUpdated={handleLotUpdated}
            onUpdateRates={handleUpdateRates}
          />
        )}

        {role === 'admin' && (
          <AdminDashboard
            categories={categories}
            recyclers={recyclers}
            lots={lots}
            language={language}
          />
        )}

        {role === 'economics' && (
          <UnitEconomicsView
            language={language}
          />
        )}
      </main>

      {/* Bottom Footer with JNARDDC & E-Waste Rules 2022 Attribution */}
      <footer className="bg-stone-900 border-t border-stone-800 text-stone-400 text-xs py-4 px-4 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Kabadiwala Connect — JNARDDC / Ministry of Mines (Problem Statement #26229)</span>
          </div>
          <p className="text-stone-400">
            Compliant with E-Waste (Management) Rules, 2022 • Offline-First PWA Architecture
          </p>
        </div>
      </footer>
    </div>
  );
}
